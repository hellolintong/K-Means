/*#include "node.h"

int MyCompare(const Node &first, const Node &second){
	int len = first.data.size();
	for(int i = 0 ;i < len; i++){
		if(first.data[i] < second.data[i]){
			return -1;
		}
		else if(first.data[i] > second.data[i]){
			return 1;
		}
	}
	return 0;
}*/